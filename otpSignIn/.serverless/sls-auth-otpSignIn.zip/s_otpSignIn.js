
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'prasanna9417',
  applicationName: 'serverless-auth',
  appUid: 'kg7b8rGN6fwpZlvfCz',
  orgUid: '0qynJP3sbnMH6Pj8yK',
  deploymentUid: '1eef884f-5978-4fca-80d5-1e01cfa7a327',
  serviceName: 'sls-auth-otpSignIn',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sls-auth-otpSignIn-dev-otpSignIn', timeout: 6 };

try {
  const userHandler = require('./lambda/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.otpSignIn, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}