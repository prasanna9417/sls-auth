
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'prasanna9417',
  applicationName: 'serverless-auth',
  appUid: 'kg7b8rGN6fwpZlvfCz',
  orgUid: '0qynJP3sbnMH6Pj8yK',
  deploymentUid: 'ae3ec6e2-11ec-4fb5-bfc8-f6ee6b471f8f',
  serviceName: 'sls-auth-signOut',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sls-auth-signOut-dev-signout-authorizer', timeout: 6 };

try {
  const userHandler = require('./authorizer/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}