
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'prasanna9417',
  applicationName: 'serverless-auth',
  appUid: 'kg7b8rGN6fwpZlvfCz',
  orgUid: '0qynJP3sbnMH6Pj8yK',
  deploymentUid: '5dcd58d5-2e27-43f0-a89a-085b9fca1528',
  serviceName: 'sls-auth-googleSignIn',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sls-auth-googleSignIn-dev-googleSignIn-authorizer', timeout: 6 };

try {
  const userHandler = require('./authorizer/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.googleOAuth2, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}