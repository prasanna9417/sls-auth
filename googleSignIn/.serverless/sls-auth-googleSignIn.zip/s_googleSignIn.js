
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'prasanna9417',
  applicationName: 'serverless-auth',
  appUid: 'kg7b8rGN6fwpZlvfCz',
  orgUid: '0qynJP3sbnMH6Pj8yK',
  deploymentUid: 'ae2c11f0-0057-4078-bd1f-cdea85954dd8',
  serviceName: 'sls-auth-googleSignIn',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sls-auth-googleSignIn-dev-googleSignIn', timeout: 6 };

try {
  const userHandler = require('./lambda/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.googleSignIn, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}