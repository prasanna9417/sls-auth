
const authSign =  "very-very-secret"

module.exports = {
   authSign
}
