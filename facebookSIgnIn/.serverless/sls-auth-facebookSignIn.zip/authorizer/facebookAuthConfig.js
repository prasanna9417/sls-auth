 
const clientId = 550965442521996
const clientSecret = "14d014504f32f88ac3dd71fb0a3820ba"


module.exports={
    facebookClientId: clientId,
    facebookClientSecret: clientSecret
}