
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'prasanna9417',
  applicationName: 'serverless-auth',
  appUid: 'kg7b8rGN6fwpZlvfCz',
  orgUid: '0qynJP3sbnMH6Pj8yK',
  deploymentUid: '0ab15acc-91e0-4d05-9fe6-c79a5a2d9168',
  serviceName: 'sls-auth-changePassword',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sls-auth-changePassword-dev-changePassword', timeout: 6 };

try {
  const userHandler = require('./lambda/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.changePassword, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}