 
const oauth_consumer_key = 'aMBKD5pK1kSAoBFJXVNaG6SHx'
const oauth_consumer_secret = 'g1jHd4u81A6Wt8EiV43hz1kYORUPiOeGsr3rjnBmnh4mJGmpRJ'
const token_verifier_url = 'https://api.twitter.com/oauth/access_token'
const verify_credentials_url = 'https://api.twitter.com/1.1/account/verify_credentials.json'

module.exports = {
    oauth_consumer_key: oauth_consumer_key,
    oauth_consumer_secret: oauth_consumer_secret,
    token_verifier_url: token_verifier_url,
    verify_credentials_url: verify_credentials_url
}

 